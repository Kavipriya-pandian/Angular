import { ButtonClickDirective } from './button-click.directive';

describe('ButtonClickDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtonClickDirective();
    expect(directive).toBeTruthy();
  });
});
