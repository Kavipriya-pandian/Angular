import { RideFilterPipe } from './ride-filter.pipe';

describe('RideFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new RideFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
