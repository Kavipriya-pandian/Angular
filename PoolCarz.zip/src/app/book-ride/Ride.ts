export class Ride {
    public id: number=0;
    public offerId: string="";
    public name: string="";
    public car: string="";
    public seatsLeft: number=0;
    public pickUp: string="";
    public destination: string='';
}